#include<stdio.h>

int main()
{
    int dias, meses, anos, restoanos, restomeses, dias2;
    scanf("%d", &dias);
    anos= (dias>=365) ? dias/365 : 0;
    restoanos= (dias>=365) ? dias%365 : 0;
    meses=restoanos>0 ? restoanos/30 : dias/30;
    restomeses=restoanos>0 ? restoanos%30 : dias%30;
    dias2=restomeses;
    printf("%d ano(s)\n", anos);
    printf("%d mês(es)\n", meses);
    printf("%d dia(s)\n", dias2);

    return 0;
}

